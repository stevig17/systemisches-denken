export default function App() {
  return <div>Systemisches Denken App – React Grundgerüst</div>
}

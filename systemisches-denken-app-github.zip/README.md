# Systemisches Denken App

Dies ist eine interaktive Lern-App zu systemischem Denken.
Deploy empfohlen über Vercel oder Netlify.
